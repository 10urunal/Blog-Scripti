<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Site Metas -->
    <title><?php echo strip_tags($ayarlar->site_title); ?></title>

<?php $this->load->view("header"); ?>
    <?php $this->load->view("slider"); ?>

        <section class="section">
            <div class="container">
                <div class="row">
                    <?php $this->load->view("yayin_akisi"); ?>

                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                        <div class="sidebar">

                            <?php $this->load->view("populer_yazilar"); ?>



                            <?php $this->load->view("sosyal_linkler"); ?>

                        </div><!-- end sidebar -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>

<?php $this->load->view("footer"); ?>
