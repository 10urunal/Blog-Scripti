                            <div class="widget">
                                <h2 class="widget-title"><i class="fa fa-instagram" aria-hidden="true"></i>&nbsp;Sosyal Medya</h2>

                                <div class="row text-center">
                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                        <a href="<?php echo strip_tags($ayarlar->site_facebook); ?>" class="social-button facebook-button">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </div>

                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                        <a href="<?php echo strip_tags($ayarlar->site_twitter); ?>" class="social-button twitter-button">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </div>

                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                        <a href="<?php echo strip_tags($ayarlar->site_google_plus); ?>" class="social-button google-button">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </div>

                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                        <a href="<?php echo strip_tags($ayarlar->site_youtube); ?>" class="social-button youtube-button">
                                            <i class="fa fa-youtube"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- end widget -->