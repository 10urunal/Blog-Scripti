                    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                        <div class="page-wrapper">
                            <div class="blog-top clearfix">
                                <h4 class="pull-left">Yayın Akışı <a href="#"><i class="fa fa-rss"></i></a></h4>
                            </div><!-- end blog-top -->

                            <div class="blog-list clearfix">
                                <?php foreach ($yazi_listesi as $row) { ?>
                                <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">                                       
                                            <a href="<?php echo base_url("yazi/".$row->yazi_url); ?>" title="">
                                                <img src="<?php echo base_url("uploads/$row->yazi_resim"); ?>" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->

                                    <div class="blog-meta big-meta col-md-8">
                                        <h4><a href="<?php echo base_url("yazi/".$row->yazi_url); ?>" title=""><?php echo mb_strimwidth($row->yazi_baslik, 0, 40,"..."); ?></a></h4>
                                        <p><?php echo mb_strimwidth($row->yazi_icerik, 0, 250,"..."); ?></p>
                                        <small class="firstsmall"><a class="bg-orange"  title=""><i class="fas fa-user-circle"></i>&nbsp;<?php echo strip_tags($row->uye_ad_soyad); ?></a></small>
                                        <small><a  title=""><i class="far fa-clock"></i>&nbsp;&nbsp;<?php $tarih = $row->createdAt; echo $this->fonksiyonlar->timeConvert($tarih); ?></a></small>
                                        <small><a  title=""><i class="material-icons pull-left">trending_up</i>&nbsp;<?php echo $row->yazi_goruntulenme; ?></a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->

                                <hr class="invis">
                                <?php } ?>
                            </div><!-- end blog-list -->
                        </div><!-- end page-wrapper -->

                        <hr class="invis">

                    <?php echo $this->pagination->create_links(); ?>
                    </div><!-- end col -->