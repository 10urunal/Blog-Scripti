<div class="collapse navbar-collapse" id="navbarCollapse">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo base_url();?>">Anasayfa</a>
                            </li>
                            <?php foreach($kategoriler as $ktg) { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo base_url("kategori/$ktg->kategori_url"); ?>"><?php echo $ktg->kategori_adi; ?></a>
                            </li>
                            <?php } ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo base_url("iletisim");?>">iletisim</a>
                            </li>
                        </ul>
                        <ul class="navbar-nav mr-2">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo strip_tags($ayarlar->site_rss); ?>"><i class="fa fa-rss"></i></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo strip_tags($ayarlar->site_googleplay); ?>"><i class="fa fa-android"></i></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo strip_tags($ayarlar->site_appstore); ?>"><i class="fa fa-apple"></i></a>
                            </li>
                        </ul>
                    </div>