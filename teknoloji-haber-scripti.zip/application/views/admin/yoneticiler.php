<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>
<?php $this->load->view("admin/menu") ?>
    <section class="content">
    	            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Yöneticiler
                            </h2>
                        </div>
                        <div class="body table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>yönetici adı</th>
                                        <th>e-mail</th>
                                        <th>yetki</th>
                                        <th>durum</th>
                                        <th>tarih</th>
                                        <th>işlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php foreach ($list as $row) { ?>
                                    <tr>
                                        <td><span class="badge bg-teal"><?php echo $row->ad_soyad; ?></span></td>
                                        <td><span class="badge bg-blue"><?php echo $row->email; ?></span></td>
                                        <td><?php if($row->user_role=="0") {echo "Yasaklı";} else if($row->user_role=="1") {echo "<span class='badge bg-orange'>üye</span>";} else if($row->user_role=="2") {echo "<span class='badge bg-pink'>editör</span>";} else if($row->user_role=="3") {echo "<span class='badge bg-purple'>moderatör</span>";} else if($row->user_role=="4") {echo "<span class='badge bg-deep-purple'>admin</span";} ?></td>
                                        <td><?php if($row->isActive=="1") {echo "<span class='badge bg-green'>Aktif</span>";} else{echo "<span class='badge bg-red'>Pasif</span>";} ?></td>
                                        <td><span class="badge bg-deep-orange"><?php echo $row->createdAt; ?></span></td>
                                        <td>
                                        	<a href="<?php echo base_url("admin/yoneticiler/duzenle/$row->id"); ?>" title="düzenle" class="btn btn-default btn-circle waves-effect waves-light-blue waves-circle waves-float pull-left">
                                        	<i class="material-icons">edit</i></a> <a href="<?php echo base_url("admin/yoneticiler/sil/$row->id"); ?>" title="sil" class="btn btn-default btn-circle waves-effect waves-red waves-circle waves-float pull-left">
                                        	<i class="material-icons">delete</i>
                                        	</a>                            
                                		</td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $this->load->view("admin/footer") ?>
