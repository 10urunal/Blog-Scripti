<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>
<?php $this->load->view("admin/menu") ?>
    <section class="content">
    	       <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Haberler
                            </h2>
                        </div>
                        <div class="body table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>başlık</th>
                                        <th>görüntülenme</th>
                                        <th>durum</th>
                                        <th>tarih</th>
                                        <th>işlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php foreach ($list as $row) { ?>
                                    <tr>
                                        <td><span class="badge bg-teal"><?php echo mb_strimwidth($row->yazi_baslik, 0, 20,"..."); ?></span></td>
                                        <td><span class="badge bg-blue"><?php echo $row->yazi_goruntulenme; ?></span></td>
                                        <td><?php if($row->yazi_durum=="1") {echo "<span class='badge bg-green'>Açık</span>";} else{echo "<span class='badge bg-red'>Kapalı</span>";} ?></td>
                                        <td><span class="badge bg-deep-orange"><?php echo $row->createdAt; ?></span></td>
                                        <td>
                                        	<a href="<?php echo base_url("admin/yazilar/duzenle/$row->id"); ?>" title="düzenle" class="btn btn-default btn-circle waves-effect waves-light-blue waves-circle waves-float pull-left">
                                        	<i class="material-icons">edit</i></a> <a href="<?php echo base_url("admin/yazilar/sil/$row->id"); ?>" title="sil" class="btn btn-default btn-circle waves-effect waves-red waves-circle waves-float pull-left">
                                            <i class="material-icons">delete</i>
                                        	</a>                            
                                		</td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $this->load->view("admin/footer") ?>
