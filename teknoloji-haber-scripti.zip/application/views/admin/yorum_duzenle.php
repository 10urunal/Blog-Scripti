<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>
<?php $this->load->view("admin/menu") ?>
    <section class="content">
        <div class="container-fluid">
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Yorum'u Düzenle
                            </h2>
                        </div>
                        <div class="body">
                                <form action="<?php echo base_url("admin/yorumlar/duzenle/update/$yorumlar->id"); ?>" method="post">
                                <input type="hidden" name="yazi_id" value="<?php echo $yorumlar->yazi_id; ?>">
                                <input type="hidden" name="id" value="<?php echo $yorumlar->id; ?>">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="yorum_ad_soyad" name="yorum_ad_soyad" value="<?php echo $yorumlar->yorum_ad_soyad; ?>" class="form-control">
                                        <label class="form-label">yorumcu</label>
                                    </div>
                                </div>

                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="yorum_email" name="yorum_email" value="<?php echo $yorumlar->yorum_email; ?>" class="form-control">
                                        <label class="form-label">e-mail</label>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <label>durum</label>
                                        <select class="form-control show-tick"  id="yorum_durum" name="yorum_durum">
                                            <option value="1" <?php if($yorumlar->yorum_durum=="1"){echo "selected";}; ?>>aktif</option>
                                            <option value="0" <?php if($yorumlar->yorum_durum=="0"){echo "selected";}; ?>>pasif</option>
                                        </select>
                                    </div>
                                </div>                                
                                 <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <label>yorum :</label>
                                        <div class="form-group">
                                            <div class="form-line">
                                                <textarea id="yorum_icerik" rows="5" name="yorum_icerik" class="form-control no-resize"><?php echo html_escape($yorumlar->yorum_icerik); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button  type="submit" class="btn btn-primary m-t-15 waves-effect">güncelle</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $this->load->view("admin/footer") ?>

