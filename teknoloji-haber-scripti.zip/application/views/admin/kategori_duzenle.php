<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>
<?php $this->load->view("admin/menu") ?>
    <section class="content">
        <div class="container-fluid">

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Kategori'yi Düzenle
                            </h2>
                        </div>
                        <div class="body">
                                <form action="<?php echo base_url("admin/kategoriler/duzenle/update/$kategoriler->id"); ?>" method="post">
                                <input type="hidden" name="yazar_id" value="<?php $user = $this->session->userdata("user"); echo $user["id"]; ?>">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="kategori_adi" name="kategori_adi" value="<?php echo $kategoriler->kategori_adi; ?>" class="form-control">
                                        <label class="form-label">kategori adı</label>
                                    </div>
                                </div>

                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="kategori_url" name="kategori_url"  value="<?php echo $kategoriler->kategori_url; ?>" class="form-control">
                                        <label class="form-label">kategori URL (boş bırakılırsa otomatik oluşturulur)</label>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <label>gösterim durumu</label>
                                        <select class="form-control show-tick"  id="kategori_durum" name="kategori_durum">
                                            <option value="1" <?php if($kategoriler->kategori_durum=="1"){echo "selected";}; ?>>açık</option>
                                            <option value="0" <?php if($kategoriler->kategori_durum=="0"){echo "selected";}; ?>>kapalı</option>
                                        </select>
                                    </div>
                                </div>                                

                                <button  type="submit" class="btn btn-primary m-t-15 waves-effect">güncelle</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $this->load->view("admin/footer") ?>

