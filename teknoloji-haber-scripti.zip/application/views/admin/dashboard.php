﻿<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>

<?php $this->load->view("admin/menu") ?>

<?php $this->load->view("admin/sidebar") ?>

<?php $this->load->view("admin/footer") ?>