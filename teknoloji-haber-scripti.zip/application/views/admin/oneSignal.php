<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author Ali Kavaklı
 * Class oneSignal
 * Date: 31.03.2019
 */

class oneSignal
{
    public $apiKey = 'c5fae77e-b308-443b-a76c-ccb108c2f19f'; // Api Key

    private $restApiKey = 'YTM5NmYxMWQtYjU0OC00MjIyLWIzM2QtNDVmOThiYjBiN2Yw'; // Rest Api Key

    function __construct()
    {
        return $this->apiKey;
    }



    public function sendMessage($messageEn ,$headings , $url = null)
    {
        $content = array(
            'en' => $messageEn
        );

        $headings = array(
            'en' => $headings
        );


        $data = array(
            'app_id' => $this->apiKey,
            'included_segments' => array('All'),
            'contents' => $content,
            'headings' => $headings,
            'url' => $url

        );
        $data = json_encode($data);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://onesignal.com/api/v1/notifications',
            CURLOPT_RETURNTRANSFER => TRUE,
            CURLOPT_HEADER => FALSE,
            CURLOPT_POST => TRUE,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_SSL_VERIFYPEER => FALSE,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json; charset=utf-8',
                'Authorization: Basic '.$this->restApiKey
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        echo '';

    }

}

