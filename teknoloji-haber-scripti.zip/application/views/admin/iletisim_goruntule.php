<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>
<?php $this->load->view("admin/menu") ?>
    <section class="content">
        <div class="container-fluid">
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Mesajlar
                            </h2>
                        </div>
                        <div class="body">
                                <div class="row clearfix">
                                   <div class="col-sm-6">
                                        <label>gönderen</label>
                                        <div class="form-group">
                                            <div class="form-line disabled">
                                                <input type="text" class="form-control" id="gonderen_ad_soyad" name="gonderen_ad_soyad" value="<?php echo $iletisim_mesajlari->gonderen_ad_soyad; ?>" disabled />
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <div class="row clearfix">
                                   <div class="col-sm-6">
                                        <label>e-mail</label>
                                        <div class="form-group">
                                            <div class="form-line disabled">
                                                <input type="text" class="form-control" id="gonderen_email" name="gonderen_email" value="<?php echo $iletisim_mesajlari->gonderen_email; ?>" disabled />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                   <div class="col-sm-6">
                                        <label>konu</label>
                                        <div class="form-group">
                                            <div class="form-line disabled">
                                                <input type="text" class="form-control" id="konu" name="konu" value="<?php echo $iletisim_mesajlari->konu; ?>" disabled />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                   <div class="col-sm-6">
                                        <label>mesaj</label>
                                        <div class="form-group">
                                            <div class="form-line disabled">
                                                <textarea rows="5" class="form-control" id="mesaj" name="mesaj" disabled><?php echo html_escape($iletisim_mesajlari->mesaj); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                                                     
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $this->load->view("admin/footer") ?>

