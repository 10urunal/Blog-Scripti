<?php
$this->load->view("admin/oneSignal");
$oneSignal = new oneSignal();

if($_POST) {

    $text = $_POST['text'];
    $headings = $_POST['headings'];
    $link = $_POST['link'];

    print_r($oneSignal->sendMessage($text, $headings, $link));
}
?>
  
<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>

<?php $this->load->view("admin/menu") ?>
    <section class="content">
        <div class="container-fluid">
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Bildirim Oluştur
                            </h2>
                        </div>
                        <div class="body">
                                <form action=""  method="post">
                                <input type="hidden" name="yazar_id" value="<?php $user = $this->session->userdata("user"); echo $user["id"]; ?>">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="headings" class="form-control" name="headings" class="form-control">
                                        <label class="form-label">bildirim başlığı</label>
                                    </div>
                                </div>

                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="text" name="text"  class="form-control">
                                        <label class="form-label">göndermek istediğiniz mesajı girin</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="link" name="link" name="text"  class="form-control">
                                        <label class="form-label">bildirime tıklandığında yönlendirilecek URL</label>
                                    </div>
                                </div>                               

                                <?php $this->load->view("admin/bildirim"); ?>
                                <a  href="javascript:void(0);" data-toggle="modal" data-target="#bildirimModal"  class="btn btn-primary m-t-15 waves-effect">gönder</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $this->load->view("admin/footer") ?>
