<?php $admin = $this->session->userdata("admin"); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Anasayfa</h2>
            </div>

            <!-- Widgets -->
            <div class="row clearfix">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">insert_drive_file</i>
                        </div>
                        <div class="content">
                            <div class="text">Haber</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo $istatistikler['yazi_sayisi']; ?>" data-speed="1500" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-indigo hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">email</i>
                        </div>
                        <div class="content">
                            <div class="text">Mesaj</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo $istatistikler['iletisim_mesaj_sayisi']; ?>" data-speed="1500" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-red hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">forum</i>
                        </div>
                        <div class="content">
                            <div class="text">Yorum</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo $istatistikler['yorum_sayisi']; ?>" data-speed="1500" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-orange hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">trending_up</i>
                        </div>
                        <div class="content">
                            <div class="text">Görüntülenme Sayisi</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo $istatistikler['yazi_goruntulenme']; ?>" data-speed="2000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Widgets -->
                        <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                son paylaşılan haberler
                                <small>bu alanda son paylaşılan 4 haber gözükmektedir.</small>
                            </h2>
                        </div>
                        <div class="body">
                            <div class="row">
                                <?php foreach ($yazi_listesi as $row) { ?>
                                <div class="col-sm-6 col-md-3">
                                    <div class="thumbnail">
                                        <img src="<?php echo base_url("uploads/$row->yazi_resim"); ?>">
                                        <div class="caption">
                                            <h3><?php echo mb_strimwidth($row->yazi_baslik, 0, 20,"..."); ?></h3>
                                            <p><?php echo mb_strimwidth($row->yazi_icerik, 0, 250,"..."); ?></p>
                                            <p>
                                            <a target="_blank" href="<?php echo base_url("yazi/$row->yazi_url"); ?>"  class="btn btn-primary waves-effect" role="button">görüntüle</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
