            <div class="modal fade" id="bildirimModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content ">
                        <div class="modal-header">
                            <h4 class="modal-title" id="bildirimModalLabel">BILGI</h4>
                        </div>
                        <div class="modal-body">
                            Bu bildirim, izin veren tüm kullanıcılara gönderilecektir. Bildirimlere ait detaylı verilere oneSignal hesabınızdan ulaşabilirsiniz.
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-link waves-effect">GONDER</a>
                        </div>
                    </div>
                </div>
            </div>
