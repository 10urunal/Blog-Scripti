<?php $admin = $this->session->userdata("admin"); ?>

<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "c5fae77e-b308-443b-a76c-ccb108c2f19f",
    });
  });
</script>
    <!-- Jquery Core Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
    <!-- Bootstrap Colorpicker Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>

    <!-- Dropzone Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/dropzone/dropzone.js"></script>
    <!-- Input Mask Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta//plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script>
    <!-- Multi Select Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/multi-select/js/jquery.multi-select.js"></script>
    <!-- Jquery Spinner Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-spinner/js/jquery.spinner.js"></script>
    <!-- Bootstrap Tags Input Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
    <!-- noUISlider Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/nouislider/nouislider.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/node-waves/waves.js"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-countto/jquery.countTo.js"></script>

    <!-- Morris Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/raphael/raphael.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/morrisjs/morris.js"></script>

    <!-- ChartJs -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/chartjs/Chart.bundle.js"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/flot-charts/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/flot-charts/jquery.flot.resize.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/flot-charts/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/flot-charts/jquery.flot.categories.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/flot-charts/jquery.flot.time.js"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-sparkline/jquery.sparkline.js"></script>
    <!-- noUISlider Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/nouislider/nouislider.js"></script>

        <!-- Jquery DataTable Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/ta/js/pages/ui/notifications.js"></script>

    <!-- Custom Js -->
    <script src="<?php echo base_url(); ?>assets/ta/js/admin.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/js/pages/index.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/js/pages/forms/advanced-form-elements.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/js/pages/tables/jquery-datatable.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-steps/jquery.steps.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/jquery-validation/jquery.validate.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/js/pages/forms/form-wizard.js"></script>
    <!-- Demo Js -->
    <script src="<?php echo base_url(); ?>assets/ta/js/demo.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/plugins/bootstrap-notify/bootstrap-notify.js"></script>

        <!-- SweetAlert Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/ta/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/ta/js/pages/ui/dialogs.js"></script>
    <?php $this->load->view("admin/alert") ?>
    <?php $this->load->view("admin/cikis_yap") ?>
</body>

</html>
