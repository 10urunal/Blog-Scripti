<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>
<?php $this->load->view("admin/menu") ?>
    <section class="content">
        <div class="container-fluid">

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Haber'i Düzenle
                            </h2>
                        </div>
                        <div class="body">
                                <form action="<?php echo base_url("admin/yazilar/duzenle/update/$yazilar->id"); ?>" method="post" enctype="multipart/form-data">
                                <input type="hidden" name="yazar_id" value="<?php $user = $this->session->userdata("user"); echo $user["id"]; ?>">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="yazi_baslik" name="yazi_baslik" value="<?php echo $yazilar->yazi_baslik; ?>" class="form-control">
                                        <label class="form-label">başlık</label>
                                    </div>
                                </div>

                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="yazi_url" name="yazi_url" value="<?php echo $yazilar->yazi_url; ?>" class="form-control">
                                        <label class="form-label">yazi URL</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="etiket" name="etiket" value="<?php echo html_escape($etikets); ?>" class="form-control">
                                        <label class="form-label">etiketler (etiketi girin ve virgül'e basın)</label>
                                    </div>
                                </div>                                
                                <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <label>kategori</label>
                                        <select class="form-control show-tick" id="yazi_kategori" name="yazi_kategori">
                                            <?php foreach ($list as $row) {
                                            ($row->id == $yazilar->kategori_id) ? $selected = "selected":$selected = "";
                                            ?>
                                            <option value="<?php echo $row->id; ?>" <?php echo $selected; ?>><?php echo $row->kategori_adi; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <label>gösterim durumu</label>
                                        <select class="form-control show-tick"  id="yazi_durum" name="yazi_durum">
                                            <option value="1" <?php if($yazilar->yazi_durum=="1"){echo "selected";}; ?>>açık</option>
                                            <option value="0" <?php if($yazilar->yazi_durum=="0"){echo "selected";}; ?>>kapalı</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <label>öne çıkan görsel</label>
                                        <input type="file" class="form-control-file" id="yazi_resim" name="yazi_resim">
                                    </div>
                                </div>
                                <div class="form-group">
                                <label for="yazi_icerik">haber içeriği</label>
                                <textarea rows="5" class="form-control" id="yazi_icerik" name="yazi_icerik"><?php echo html_escape($yazilar->yazi_icerik); ?></textarea>
                                </div>
                                <input type="hidden" name="id" value="<?php echo $yazilar->id; ?>"> 
                                <button  type="submit" class="btn btn-primary m-t-15 waves-effect">güncelle</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<script src="<?php echo base_url("assets/plugins/ckeditor/ckeditor.js"); ?>"></script>
<script>
CKEDITOR.replace('yazi_icerik', {
extraPlugins: 'syntaxhighlight'
});
</script>
<?php $this->load->view("admin/footer") ?>

