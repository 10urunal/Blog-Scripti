<?php $admin = $this->session->userdata("admin"); ?>
    <section>
        <!-- Sol menü -->
        <aside id="leftsidebar" class="sidebar">
            <!-- admin bilgileri -->
            <div class="user-info">
                <div class="image">
                    <img src="<?php echo base_url(); ?>assets/ta/images/user.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Yönetici</div>
                    <div class="email">ali.nicoles45200@gmail.com</div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="javascript:void(0);" data-toggle="modal" data-target="#exampleModal" ><i class="material-icons">input</i>Çıkış</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #admin bilgileri -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">ARAÇLAR</li>
                    <li>
                        <a href="<?php echo base_url(); ?>admin">
                            <i class="material-icons">home</i>
                            <span>Anasayfa</span>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">insert_drive_file</i>
                            <span>Haberler</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url("admin/yazilar/ekle"); ?>">Haber ekle</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url("admin/yazilar"); ?>">Haberler</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">storage</i>
                            <span>Kategoriler</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url("admin/kategoriler/ekle"); ?>">Kategori ekle</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url("admin/kategoriler"); ?>">Kategoriler</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">verified_user</i>
                            <span>Yöneticiler</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url("admin/yoneticiler/ekle"); ?>">Yönetici ekle</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url("admin/yoneticiler"); ?>">Yöneticiler</a>
                            </li>
                        </ul>
                    </li>
                    <li class="header">EKLENTILER</li>
                    <li>
                        <a href="<?php echo base_url("admin/yorumlar"); ?>">
                            <i class="material-icons">forum</i>
                            <span>Yorumlar</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url("admin/iletisim"); ?>">
                            <i class="material-icons">email</i>
                            <span>Iletişim</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url("admin/sayfalar"); ?>">
                            <i class="material-icons">notifications_active</i>
                            <span>Bildirim</span>
                        </a>
                    </li>                    
                    <!-- AYARLAR -->
                    <li class="header">AYARLAR</li>
                    <li>
                        <a href="<?php echo base_url("admin/ayarlar"); ?>">
                            <i class="material-icons">settings</i>
                            <span>Ayarlar</span>
                        </a>
                    </li>
                    <!-- AYARLAR -->
                </ul>
            </div>
            <!-- #Menu -->
            <!-- menu footer -->
            <div class="legal">
                <div class="copyright">
                    <a href="javascript:void(0);">yönetimPaneli</a> &copy; 2019
                </div>
                <div class="version">
                    <b>Sürüm: </b> 1.0.0
                </div>
            </div>
            <!-- #menu footer -->
        </aside>
        <!-- #END# sol menu  -->
    </section>