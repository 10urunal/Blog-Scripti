            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content ">
                        <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel">Uyarı !</h4>
                        </div>
                        <div class="modal-body">
                            Çıkış yaparsanız mevcut oturum ve panel erişiminiz sonlanacaktır. Panele tekrar erişmek için giriş yapmanız gerekmektedir.
                        </div>
                        <div class="modal-footer">
                            <a class="btn btn-link waves-effect" data-dismiss="modal">IPTAL</a>
                            <a href="<?php echo base_url("admin/cikis"); ?>" class="btn btn-link waves-effect">ÇIKIŞ YAP</a>
                        </div>
                    </div>
                </div>
            </div>
