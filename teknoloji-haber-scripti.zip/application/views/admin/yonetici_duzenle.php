<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>
<?php $this->load->view("admin/menu") ?>
    <section class="content">
        <div class="container-fluid">
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Yönetici'yi Düzenle
                            </h2>
                        </div>
                        <div class="body">
                                <form action="<?php echo base_url("admin/yoneticiler/duzenle/update/$yoneticiler->id"); ?>" method="post">
                                <input type="hidden" name="ekleyen_id" value="<?php $user = $this->session->userdata("user"); echo $user["id"]; ?>">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="ad_soyad" value="<?php echo $yoneticiler->ad_soyad; ?>"" name="ad_soyad" class="form-control">
                                        <label class="form-label">ad & soyad</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="email" value="<?php echo $yoneticiler->email; ?>" name="email"  class="form-control">
                                        <label class="form-label">e-mail adresi</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="sifre" name="sifre"  class="form-control">
                                        <label class="form-label">şifre (değiştirmeyecekseniz boş bırakın)</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="telefon" value="<?php echo $yoneticiler->telefon; ?>" name="telefon"  class="form-control">
                                        <label class="form-label">telefon numarası (zorunlu değil)</label>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <label>cinsiyet</label>
                                        <select class="form-control show-tick"  id="cinsiyet" name="cinsiyet">
                                            <option value="1" <?php if($yoneticiler->cinsiyet=="e"){echo "selected";}; ?>>erkek</option>
                                            <option value="2" <?php if($yoneticiler->cinsiyet=="k"){echo "selected";}; ?>>kadın</option>
                                        </select>
                                    </div>
                                </div>                                
                                <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <label>yetki</label>
                                        <select class="form-control show-tick"  id="user_role" name="user_role">
                                            <option value="4" <?php if($yoneticiler->user_role=="4"){echo "selected";}; ?>>admin</option>
                                            <option value="3" <?php if($yoneticiler->user_role=="3"){echo "selected";}; ?>>moderatör</option>
                                            <option value="2" <?php if($yoneticiler->user_role=="2"){echo "selected";}; ?>>editör</option>
                                            <option value="1" <?php if($yoneticiler->user_role=="1"){echo "selected";}; ?>>üye</option>
                                            <option value="0" <?php if($yoneticiler->user_role=="0"){echo "selected";}; ?>>yasaklı</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <label>durum</label>
                                        <select class="form-control show-tick"  id="isActive" name="isActive">
                                            <option value="1" <?php if($yoneticiler->isActive=="1"){echo "selected";}; ?>>aktif</option>
                                            <option value="0" <?php if($yoneticiler->isActive=="0"){echo "selected";}; ?>>pasif</option>
                                        </select>
                                    </div>
                                </div>  
                                <button  type="submit" class="btn btn-primary m-t-15 waves-effect">kaydet</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $this->load->view("admin/footer") ?>

