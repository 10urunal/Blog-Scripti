<?php $admin = $this->session->userdata("admin"); ?>
<?php $this->load->view("admin/header") ?>
<?php $this->load->view("admin/menu") ?>
    <section class="content">
        <div class="container-fluid">
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Site Ayarları
                            </h2>
                        </div>
                        <div class="body">
                                <form action="<?php echo base_url("admin/ayarlar/update"); ?>" method="post" enctype="multipart/form-data">
                                <input type="hidden" name="guncelleyen_id" value="<?php $user = $this->session->userdata("user"); echo $user["id"]; ?>">
                                <?php foreach ($genel_ayarlar as $row) { ?>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_title" value="<?php echo $row->site_title; ?>" class="form-control">
                                        <label class="form-label">site başlığı</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_footer" value="<?php echo $row->site_footer; ?>" class="form-control">
                                        <label class="form-label">site footer</label>
                                    </div>
                                </div>

                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_description" value="<?php echo $row->site_description; ?>"  class="form-control">
                                        <label class="form-label">site açıklaması</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_keywords" value="<?php echo $row->site_keywords; ?>"  class="form-control">
                                        <label class="form-label">site keywords</label>
                                    </div>
                                </div>                                
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="anasayfa_yazi_sayisi" value="<?php echo $row->anasayfa_yazi_sayisi; ?>"  class="form-control">
                                        <label class="form-label">anasayfada gösterilecek haber sayısı</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="anasayfa_kategori_sayisi" value="<?php echo $row->anasayfa_kategori_sayisi; ?>"  class="form-control">
                                        <label class="form-label">kategori listeleme sayfasında gösterilecek haber sayısı</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="anasayfa_etiket_sayisi" value="<?php echo $row->anasayfa_etiket_sayisi; ?>"  class="form-control">
                                        <label class="form-label">etiket listeleme sayfasında gösterilecek haber sayısı</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="arama_yazi_sayisi" value="<?php echo $row->arama_yazi_sayisi; ?>"  class="form-control">
                                        <label class="form-label">arama sayfasında gösterilecek haber sayısı</label>
                                    </div>
                                </div>
                                <hr><hr>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_appstore" value="<?php echo $row->site_appstore; ?>"  class="form-control">
                                        <label class="form-label">appstore</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_googleplay" value="<?php echo $row->site_googleplay; ?>"  class="form-control">
                                        <label class="form-label">googleplay</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_rss" value="<?php echo $row->site_rss; ?>"  class="form-control">
                                        <label class="form-label">rss</label>
                                    </div>
                                </div>                                   
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_facebook" value="<?php echo $row->site_facebook; ?>"  class="form-control">
                                        <label class="form-label">facebook</label>
                                    </div>
                                </div>                                                                                                     <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_twitter" value="<?php echo $row->site_twitter; ?>"  class="form-control">
                                        <label class="form-label">twitter</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_instagram" value="<?php echo $row->site_instagram; ?>"  class="form-control">
                                        <label class="form-label">instagram</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_youtube" value="<?php echo $row->site_youtube; ?>"  class="form-control">
                                        <label class="form-label">youtube</label>
                                    </div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" name="site_google_plus" value="<?php echo $row->site_google_plus; ?>"  class="form-control">
                                        <label class="form-label">google+</label>
                                    </div>
                                </div>                                              
                                <button  type="submit" class="btn btn-primary m-t-15 waves-effect">kaydet</button>
                                <?php } ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $this->load->view("admin/footer") ?>

