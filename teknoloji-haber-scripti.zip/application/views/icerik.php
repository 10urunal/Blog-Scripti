<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Site Metas -->
    <title><?php echo $yazi_icerik->yazi_baslik; ?> | <?php echo strip_tags($ayarlar->site_title); ?></title>

<?php $this->load->view("header"); ?>
        <section class="section single-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                        <div class="page-wrapper">
                            <div class="blog-title-area text-center">

                                <div class="single-post-media">
                                    <img src="<?php echo base_url("uploads/$yazi_icerik->yazi_resim"); ?>" alt="" class="img-fluid">
                                </div><!-- end media -->

                                <span class="color-orange"><a href="<?php echo base_url("kategori/".strip_tags($yazi_icerik->kategori_url)); ?>" title=""><?php echo strip_tags($yazi_icerik->kategori_adi); ?></a></span>


                                <h3><?php echo $yazi_icerik->yazi_baslik; ?></h3>

                                <div class="blog-meta big-meta">
                                    <small class="firstsmall"><a class="bg-orange"  title=""><i class="fas fa-user-circle"></i>&nbsp;<?php echo strip_tags($yazi_icerik->uye_ad_soyad); ?></a></small>
                                    <small><a title=""><i class="fas fa-clock"></i>&nbsp;<?php $tarih = $yazi_icerik->createdAt; echo $this->fonksiyonlar->timeConvert($tarih); ?></a></small>
                                        <small><a  title=""><i class="material-icons pull-left">trending_up</i>&nbsp;<?php echo $yazi_icerik->yazi_goruntulenme; ?></a></small>
                                </div><!-- end meta -->

                                <div class="post-sharing">
                                    <ul class="list-inline">
                                        <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo base_url("yazi/".$yazi_icerik->yazi_url); ?>" class="fb-button btn btn-primary"><i class="fa fa-facebook"></i> <span class="down-mobile">Facebook'ta paylaş</span></a></li>
                                        <li><a href="https://twitter.com/intent/tweet?url=<?php echo base_url("yazi/".$yazi_icerik->yazi_url); ?>" class="tw-button btn btn-primary"><i class="fa fa-twitter"></i> <span class="down-mobile">Twitter'da paylaş</span></a></li>
                                        <li><a href="https://plus.google.com/share?url=<?php echo base_url("yazi/".$yazi_icerik->yazi_url); ?>" class="gp-button btn btn-primary"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div><!-- end post-sharing -->
                            </div><!-- end title -->


                            <div class="blog-content">  
                                <div class="pp">
                                    <p><?php echo $yazi_icerik->yazi_icerik; ?></p>

                                </div><!-- end pp -->

                            </div><!-- end content -->

                            <div class="blog-title-area">

                            <?php if(empty(!$yazi_etiketler)) { ?>
                                <div class="tag-cloud-single">
                                    <span>Etiketler</span>
                                    <?php foreach ($yazi_etiketler as $etiket) : ?>
                                    <small><a title="<?php echo strip_tags($etiket->etiket); ?>"><?php echo strip_tags($etiket->etiket); ?></a></small>
                                    <?php endforeach; ?>
                                </div><!-- end meta -->
                             <?php } ?>

                            </div><!-- end title -->
                             <hr class="invis1">
                            <?php $this->load->view("yorumlar"); ?>
                             <hr class="invis1">

                            <div class="custombox clearfix">
                                <h4 class="small-title">yorum yap</h4>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <form method="post" action="<?php echo base_url("yorum-ekle"); ?>" class="form-wrapper">
                                            <input type="hidden" name="yazi_id" value="<?php echo $yazi_icerik->id; ?>">
                                            <input type="hidden" name="yazi_url" value="<?php echo $yazi_icerik->yazi_url; ?>">
                                            <input type="text" name="yorum_ad_soyad" class="form-control" placeholder="isim">
                                            <input type="text" name="yorum_email" class="form-control" placeholder="e-mail">
                                            <textarea name="yorum_icerik" class="form-control" placeholder="yorumunuz"></textarea>
                                            <button type="submit" class="btn btn-primary">yorum yap</button>
                                        </form>
                                    </div>
                                </div>
                            </div>


                            <hr class="invis1">


                        </div><!-- end page-wrapper -->
                    </div><!-- end col -->

                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                        <div class="sidebar">

                        <?php $this->load->view("populer_yazilar"); ?>
                        <?php $this->load->view("sosyal_linkler"); ?>


                        </div><!-- end sidebar -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
<?php $this->load->view("footer"); ?>