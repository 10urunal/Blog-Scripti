                            <div class="custombox clearfix">
                                <h4 class="small-title">yorumlar</h4>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="comments-list">

                                            <?php if(!empty($yorumlar)){ ?>
                                            <?php } else { ?>
                                            <div class="alert alert-info" role="alert">
                                              <strong><?php echo $yazi_icerik->yazi_baslik; ?></strong> haberi için henüz yorum yapılmadı.
                                            </div> 
                                            <?php }
                                            foreach ($yorumlar as $yorum) : ?>
                                            <div class="media">
                                                <a class="media-left">
                                                    <img src="<?php echo base_url("assets/images/user.png"); ?>" alt="" class="rounded-circle">
                                                </a>
                                                <div class="media-body">
                                                    <h4 class="media-heading user_name"><?php echo strip_tags($yorum->yorum_ad_soyad); ?> <small> <?php $tarih = $yorum->createdAt; echo $this->fonksiyonlar->timeConvert($tarih); ?></small></h4>
                                                    <p><?php echo $yorum->yorum_icerik; ?></p>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                        </div>
                                    </div><!-- end col -->
                                </div><!-- end row -->
                            </div><!-- end custom-box -->

