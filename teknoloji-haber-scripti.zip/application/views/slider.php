        <section class="section first-section">
            <div class="container-fluid">
                <div class="masonry-blog clearfix">

                    <?php foreach(slider() as $slider) { ?>
                    <div class="second-slot">
                        <div class="masonry-box post-media">
                             <img src="<?php echo base_url("uploads/$slider->yazi_resim"); ?>" height="275" alt="">
                             <div class="shadoweffect">
                                <div class="shadow-desc">
                                    <div class="blog-meta">
                                        <span class="bg-orange"><a href="<?php echo base_url("kategori/".strip_tags($slider->kategori_url)); ?>" title=""><?php echo strip_tags($slider->kategori_adi); ?></a></span>
                                        <h4><a href="<?php echo base_url("yazi/".$slider->yazi_url); ?>" title=""><?php echo mb_strimwidth($slider->yazi_baslik, 0, 40,"..."); ?></a></h4>
                                        <small><a title=""><i class="far fa-clock"></i>&nbsp;<?php $tarih = $slider->createdAt; echo $this->fonksiyonlar->timeConvert($tarih); ?></a></small>
                                        <small><a title="<?php echo $slider->yazi_goruntulenme; ?> kez görüntülendi"><i class="material-icons pull-left">trending_up</i>&nbsp;<?php echo $slider->yazi_goruntulenme; ?></a></small>
                                    </div><!-- end meta -->
                                </div><!-- end shadow-desc -->
                             </div><!-- end shadow -->
                        </div><!-- end post-media -->
                    </div><!-- end second-side -->
                    <?php } ?>
                </div><!-- end masonry -->
            </div>
        </section>